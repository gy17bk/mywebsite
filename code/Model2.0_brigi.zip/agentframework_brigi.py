# -*- coding: utf-8 -*-
"""
Created on Sat Nov  2 17:01:00 2019

@author: Brigi
"""
import random

#this defines the Agent class with an __init__ method
class Agent():
    def __init__(self, environment, agents, y, x ): #deleted i and added y, x
        
       #self.i = i;
       self.environment = environment
       self.store = 0
       #added these
       if (y == None):
           self.y = random.randint(0, 100)
       else:
           self.y = y
# added these
       if (x == None):
               self.x = random.randint(0, 100)
       else:
               self.x = x  # instead of self._x
       #self.y = random.randint(0,99)
       #self.x = random.randint(0,99)
       
       self.agents = agents
       self.store = 0

       
    def __str__(self):
        return "Agent(" + ", x=" + str(self.x) \
        + ", y=" + str(self.y) + ", store=" + str(self.store) + ")"
       
    def randomize(self):
        self.y = random.randint(0,99)
        self.x = random.randint(0,99)

#this defines the move method within the Agent class
    def move (self): 
        if random.random() < 0.5:
            self.y = (self.y + 1) % 100
        else:
            self.y = (self.y - 1) % 100

        if random.random() < 0.5:
            self.x = (self.x + 1) % 100
        else:
            self.x = (self.x - 1) % 100 
            
    def eat(self): 
        if self.environment[self.y][self.x] > 10:
            self.environment[self.y][self.x] -= 10
            self.store += 10
            
    def distance_between(self, agent): 
        return (((self.x - agent.x)**2) + 
                ((self.y - agent.y)**2))**0.5
                
#this method is to get the agents communicate with each other
    def share_with_neighbours(self, neighbourhood): 
         for agent in self.agents: # loops through the agents in self.agents
             dist = self.distance_between(agent) #this calculates the dist. between
                                                 #self and other agent
             if dist <= neighbourhood: # if the distance is less than or equal to
                                        #the neighbourhood, sums it
                 sum = self.store + agent.store
                 ave = sum /2
                 print(self, "shares with", agent, "distance", str(dist), str(ave))
                 self.store = ave
                 agent.store = ave


 
